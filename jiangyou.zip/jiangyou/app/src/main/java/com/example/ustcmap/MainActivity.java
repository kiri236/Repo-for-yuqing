package com.example.ustcmap;
import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.view.ScaleGestureDetector;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private ImageView imageViewMap;
    private ScaleGestureDetector scaleGestureDetector;
    private float scaleFactor = 1.0f;

    @SuppressLint({"ClickableViewAccessibility", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.westcampus);
        imageViewMap = findViewById(R.id.westmap);
    }
}